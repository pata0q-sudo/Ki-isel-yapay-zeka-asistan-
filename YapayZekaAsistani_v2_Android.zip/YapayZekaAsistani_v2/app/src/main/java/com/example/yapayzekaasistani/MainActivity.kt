package com.example.yapayzekaasistani

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import java.net.HttpURLConnection
import java.net.URL
import org.json.JSONObject

class MainActivity: Activity() {
 private val p by lazy { getSharedPreferences("a",0) }
 private lateinit var chat: LinearLayout
 private lateinit var input: EditText
 private lateinit var internet: Switch
 private lateinit var key: EditText

 override fun onCreate(b:Bundle?) { super.onCreate(b); build() }

 private fun build() {
  val s=ScrollView(this); val r=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(24,24,24,24)}
  s.addView(r)
  r.addView(TextView(this).apply{text="Yapay Zeka Asistanım";textSize=28f})
  internet=Switch(this).apply{text="İnternet erişimine izin ver";isChecked=p.getBoolean("net",false)}
  r.addView(internet)
  internet.setOnCheckedChangeListener{_,v->p.edit().putBoolean("net",v).apply()}
  key=EditText(this).apply{hint="OpenAI API anahtarı (cihazda saklanır)";inputType=129}
  r.addView(key)
  key.setText(p.getString("key",""))
  r.addView(Button(this).apply{text="API anahtarını kaydet";setOnClickListener{p.edit().putString("key",key.text.toString()).apply();toast("Kaydedildi")}})
  r.addView(TextView(this).apply{text="\nSohbet";textSize=20f})
  chat=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
  r.addView(chat)
  input=EditText(this).apply{hint="Mesajını yaz..."}
  r.addView(input)
  r.addView(Button(this).apply{text="Gönder";setOnClickListener{send()}})
  r.addView(TextView(this).apply{text="\nGüvenlik: İnternet kapalıyken ağ isteği yapılmaz. İnternet açıkken yalnızca uygulamanın tanımladığı API adresine istek gönderilir."})
  setContentView(s)
 }

 private fun send(){
  val q=input.text.toString().trim(); if(q.isEmpty())return
  add("Sen: $q"); input.text.clear()
  if(!internet.isChecked){add("Asistan: İnternet erişimi kapalı. Ayarlardan açarsan API isteği gönderebilirim.");return}
  val k=key.text.toString().trim()
  if(k.isEmpty()){add("Asistan: Önce API anahtarını kaydetmelisin.");return}
  add("Asistan: Yanıt hazırlanıyor…")
  Thread{
   val answer=try{callOpenAI(k,q)}catch(e:Exception){"Hata: "+e.message}
   runOnUiThread{ if(chat.childCount>0) chat.removeViewAt(chat.childCount-1); add("Asistan: $answer")}
  }.start()
 }

 private fun callOpenAI(k:String,q:String):String{
  val c=URL("https://api.openai.com/v1/responses").openConnection() as HttpURLConnection
  c.requestMethod="POST"; c.doOutput=true; c.setRequestProperty("Authorization","Bearer $k");c.setRequestProperty("Content-Type","application/json")
  val body=JSONObject().put("model","gpt-4.1-mini").put("input",q).toString()
  c.outputStream.use{it.write(body.toByteArray())}
  val text=(if(c.responseCode in 200..299)c.inputStream else c.errorStream).bufferedReader().readText()
  if(c.responseCode !in 200..299) return "API hatası: $text"
  val j=JSONObject(text)
  return j.optString("output_text").ifBlank{ text }
 }

 private fun add(t:String){chat.addView(TextView(this).apply{text=t;textSize=16f;setPadding(0,12,0,12)})}
 private fun toast(t:String)=Toast.makeText(this,t,Toast.LENGTH_SHORT).show()
}
