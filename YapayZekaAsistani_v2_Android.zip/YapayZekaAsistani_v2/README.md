Yapay Zeka Asistanım v2
- Android sohbet arayüzü
- OpenAI Responses API bağlantısı
- Kullanıcının açıp kapattığı internet erişimi
- API anahtarını cihazın SharedPreferences alanında saklama
- İnternet kapalıyken API isteği gönderilmez
- Android Studio ile APK derlenebilir
Not: API anahtarını doğrudan mobil uygulamaya koymak üretim güvenliği açısından ideal değildir; gerçek dağıtımda sunucu tarafı proxy önerilir.
